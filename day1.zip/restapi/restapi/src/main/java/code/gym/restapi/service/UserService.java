 package code.gym.restapi.service;

import java.util.List;

import code.gym.restapi.entity.User;

public interface UserService {
User createUser(User User);

User getUserById(Long userId);

List<User> getAllUser();

User updateUser(User user);
void deleteUser(Long id);
}
