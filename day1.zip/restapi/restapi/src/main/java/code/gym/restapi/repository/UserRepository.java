package code.gym.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import code.gym.restapi.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{

}
