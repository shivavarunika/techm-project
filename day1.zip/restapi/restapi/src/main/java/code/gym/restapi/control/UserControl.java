package code.gym.restapi.control;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import code.gym.restapi.entity.User;
import code.gym.restapi.service.UserService;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/api/users")
public class UserControl {

	private UserService userService;
	@PostMapping
	public ResponseEntity<User> CreateUser(@RequestBody User user){
		User saveUser=userService.createUser(user);
		return new ResponseEntity<User>(saveUser, HttpStatus.CREATED);
	}
	
	@GetMapping("{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id")Long id){
		User user=userService.getUserById(id);
		return new ResponseEntity<>(user,HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<User>> getAllUsers(){
		List<User> users=userService.getAllUser();
		return new ResponseEntity<>(users,HttpStatus.OK);
	}
	@PutMapping("{idd}")
	public ResponseEntity<User> updateUser(@PathVariable("idd") long id,@RequestBody User user){
		user.setId(id);
		User updateUser=userService.updateUser(user);
		return new ResponseEntity<>(user,HttpStatus.OK);
	}
    @DeleteMapping("{idd}")
    public ResponseEntity<String> deleteUser(@PathVariable("idd") Long id){
    	 userService.deleteUser(id); 
    	return new ResponseEntity<>("User deleted",HttpStatus.OK);
    }
	}

