package code.gym.restapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import code.gym.restapi.entity.User;
import code.gym.restapi.repository.UserRepository;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService{

	private UserRepository userRepository;
	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public User getUserById(Long id) {
		Optional<User> optionalUser=userRepository.findById(id);
		return optionalUser.get();
	}

	@Override
	public List<User> getAllUser() {
		
		return userRepository.findAll();
	}

	@Override
	public User updateUser(User user) {
	    User existingUser = userRepository.findById(user.getId()).orElseThrow(() -> new RuntimeException("User not found"));
	    existingUser.setName(user.getName());
	    existingUser.setEmail(user.getEmail());
	    return userRepository.save(existingUser);
	}

	@Override
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
		
	}

}
